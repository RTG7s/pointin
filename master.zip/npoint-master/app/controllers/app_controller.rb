class AppController < ApplicationController
  def index
    # renders the app template by default
  end
end
